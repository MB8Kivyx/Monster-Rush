using UnityEngine;

public class ObstacleManager : MonoBehaviour
{
    [Header("Player")]
    [SerializeField] private Transform player;

    [Header("Obstacle Arrays")]
    [SerializeField] private GameObject[] easyObstaclePrefabs;
    [SerializeField] private GameObject[] normalObstaclePrefabs;

    [Header("Lane Settings")]
    [Tooltip("X positions for lanes (Size = 3)")]
    [SerializeField] private float[] laneXPositions = new float[3];

    [Header("Spawn Settings")]
    [SerializeField] private float spawnStartY = 7f;
    [SerializeField] private int distanceBetweenObstacles = 25;

    [Header("Movement Settings")]
    [SerializeField] private float obstacleSpeed = 4f;
    [SerializeField] private float destroyY = -7f;

    [Header("Debug")]
    [SerializeField] private bool disableSpawning = false;

    private int obstacleIndex = 0;
    private int playerCheckpoint = -1;

    void Start()
    {
        SpawnObstacle();
    }

    void Update()
    {
        int currentCheckpoint = (int)(player.position.y / distanceBetweenObstacles);

        if (currentCheckpoint != playerCheckpoint)
        {
            SpawnObstacle();
            playerCheckpoint = currentCheckpoint;
        }
    }

    void SpawnObstacle()
    {
        if (disableSpawning)
        {
            obstacleIndex++;
            return;
        }

        GameObject[] selectedArray;

        int score = ScoreManager.Instance.GetScore();

        // Difficulty logic (same as Wave template)
        if (score < 20)
            selectedArray = easyObstaclePrefabs;
        else
            selectedArray = normalObstaclePrefabs;

        if (selectedArray == null || selectedArray.Length == 0)
            return;

        int randomObstacle = Random.Range(0, selectedArray.Length);
        int randomLane = Random.Range(0, laneXPositions.Length);

        float spawnX = laneXPositions[randomLane];
        float spawnY = spawnStartY + (obstacleIndex * distanceBetweenObstacles);

        GameObject obstacle = Instantiate(
            selectedArray[randomObstacle],
            new Vector3(spawnX, spawnY, 0f),
            Quaternion.identity
        );

        obstacle.transform.SetParent(transform);

        obstacle.AddComponent<RuntimeObstacle>().Init(this);

        obstacleIndex++;
    }

    // ---------------- RUNTIME OBSTACLE MOVEMENT ----------------
    private class RuntimeObstacle : MonoBehaviour
    {
        private ObstacleManager manager;

        public void Init(ObstacleManager m)
        {
            manager = m;
        }

        void Update()
        {
            transform.Translate(Vector3.down * manager.obstacleSpeed * Time.deltaTime);

            if (transform.position.y < manager.destroyY)
                Destroy(gameObject);
        }
    }
}
